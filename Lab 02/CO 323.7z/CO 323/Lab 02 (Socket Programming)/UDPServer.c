/* Sample UDP server */
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>
#include <stdio.h>
int main(int argc, char**argv)
{
int sockfd,n;
struct sockaddr_in servaddr, cliaddr;
socklen_t len;
char mesg[1000];
//for recieving msg
char str[100];

char* banner = "Hello UDP client! This is UDP server";
sockfd=socket(AF_INET,SOCK_DGRAM,0);
servaddr.sin_family = AF_INET;
servaddr.sin_addr.s_addr=htonl(INADDR_ANY);
servaddr.sin_port=htons(32000);
bind(sockfd,(struct sockaddr *)&servaddr,sizeof(servaddr));

//here is the client part make this infinite
while(1){
	//read
len = sizeof(cliaddr);
n = recvfrom(sockfd,mesg,1000,0,(struct sockaddr *)&cliaddr,&len);
sendto(sockfd,banner,n,0,(struct sockaddr *)&cliaddr,sizeof(cliaddr));
mesg[n] = 0;
printf("Received: %s\n",mesg);
//read from clients we need read method
read(1,str,100);
//print what is said by the clients
printf("CLients said : %s ",str);

//write(1,"\n Client typed : "+str,100);
}//end of while
return 0;
}